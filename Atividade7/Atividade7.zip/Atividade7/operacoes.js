var num1 = parseFloat(prompt("Digite um número: "));
var num2 = parseFloat(prompt("Digite outro número: "));
var soma;
var sub;
var mult;
var div;
var restDiv;

soma = num1 + num2;

sub = num1 - num2;

mult = num1 * num2;

div = num1 / num2;

restDiv = num1 % num2;

alert("A soma de " + num1 + " e " + num2 + " é: " + soma);
alert("A subtração de " + num1 + " e " + num2 + " é: " + sub);
alert("A multiplicação de " + num1 + " e " + num2 + " é: " + mult);
alert("A Divisão de " + num1 + " e " + num2 + " é: " + div);
alert("O resto da divisão de " + num1 + " e " + num2 + " é: " + restDiv);