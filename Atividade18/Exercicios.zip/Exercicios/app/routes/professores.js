module.exports = function(app){
    app.get('/informacao/professores', function(req,res){
    const sql = require ('mssql/msnodesqlv8');
    const sqlConfig = {
    user: 'BD2211033',
    password: 'Nova_Senha',
    database: 'BD', //Na FATEC, utilizar o database LP8
    server: 'apolo', //Na FATEC, utilizar o ip: 192.168.1.6 no nome do servidor
    }
   
    async function getProfessores() {
    try {
    const pool = await sql.connect(sqlConfig);
   
    const results = await pool.request().query('SELECT * from PROFESSORES')
   
    res.render('informacao/professores',{profs : results.recordset});
   
    } catch (err) {
    console.log(err)
    }
    }
    getProfessores();
    });
}