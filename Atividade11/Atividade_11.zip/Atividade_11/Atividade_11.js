var aluno1 = new Object();
aluno1.ra = "00001234";
aluno1.nome = "Xamuel";
alert("ra = " + aluno1.ra + "\nnome = " + aluno1.nome);

var aluno2 = {};
aluno2.ra = "1235";
aluno2.nome = "Mauricio de Souza";
alert("ra = " + aluno2.ra + "\nnome = " + aluno2.nome);

var aluno3 = {
    ra: "234123",
    nome: "Daiane dos Santos"
};
alert("ra = " + aluno3.ra + "\nnome = " + aluno3.nome);

function Aluno(ra, nome) {
    this.ra = ra;
    this.nome = nome;

    this.MostraDados = function() {
        return "ra = " + this.ra + "\nnome = " + this.nome;
    }
}
var aluno4 = new Aluno("123", "Papaco");
alert(aluno4.MostraDados());
alert(aluno4.nome);

var aluno5 = {};
var nome_propriedade = "ra";
aluno5[nome_propriedade] = "123";
aluno5['nome'] = "Cutelão";
alert(aluno5.ra + "\n" + aluno5.nome);